﻿using System.Windows.Controls;

namespace factory_automation_system_FAS_.Views
{
    public partial class MapView : UserControl
    {
        public MapView()
        {
            InitializeComponent();
        }
    }
}
