// Views/SettingsView.xaml.cs
using System.Windows.Controls;

namespace factory_automation_system_FAS_.Views
{
    public partial class SettingsView : UserControl
    {
        public SettingsView()
        {
            InitializeComponent();
        }
    }
}
